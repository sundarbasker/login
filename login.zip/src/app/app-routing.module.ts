import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { LoginComponent } from './login/login.component';
import { ProductListComponent } from './product-list/product-list.component';

import { AuthGuard } from './guards/auth.guard';
//import { ProudctDetailsComponent } from './components/proudct-details/proudct-details.component';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { ProductRatingsComponent } from './product-ratings/product-ratings.component';

import { ProductOffersComponent } from './product-offers/product-offers.component';

const routes: Routes = [

{path: '', component:ProductListComponent, pathMatch:'full', canActivate: [AuthGuard]},
  {path: 'login', component:LoginComponent},
  {path: 'products', component:ProductListComponent, canActivate: [AuthGuard]},
  {path: 'products', component:ProductListComponent, canActivate: [AuthGuard]},
  {
    path: 'product/:id', component: ProductDetailsComponent,canActivateChild: [AuthGuard],
    children: [
      { path: 'rating', component: ProductRatingsComponent, canDeactivate: [AuthGuard] },
      { path: 'offers', component: ProductOffersComponent }
    ]
  },
  {
    path: 'service',
    loadChildren: () => import('./modules/product-service/product-service.module').then(m => m.ProductServiceModule),
    canLoad: [AuthGuard]
  },
  {path: '**', component:ProductListComponent, pathMatch:'full', canActivate: [AuthGuard]}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
